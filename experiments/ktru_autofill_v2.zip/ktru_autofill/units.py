"""Единицы измерения: распознавание написания и приведение к единице характеристики.

«80 грамм» для плотности → 80 г/м² (контекстный синоним характеристики),
«1,2 м» для ширины в мм → 1200 мм (перевод внутри одной величины).
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from .text import _parse


@dataclass(frozen=True)
class Unit:
    name: str  # каноническое написание: «мм», «г/м²»
    dim: str  # величина: length, mass, …
    factor: float  # множитель к базовой единице величины


# Каноническое имя, величина, множитель, написания (без точек, в любом падеже — лемматизируются).
_UNITS: list[tuple[str, str, float, list[str]]] = [
    ("мкм", "length", 0.001, ["мкм", "микрон", "микрометр"]),
    ("мм", "length", 1, ["мм", "миллиметр"]),
    ("см", "length", 10, ["см", "сантиметр"]),
    ("м", "length", 1000, ["м", "метр"]),
    ("мг", "mass", 0.001, ["мг", "миллиграмм"]),
    ("г", "mass", 1, ["г", "гр", "грамм"]),
    ("кг", "mass", 1000, ["кг", "килограмм", "kg"]),
    ("т", "mass", 1_000_000, ["т", "тонна", "метрическая тонна"]),
    ("мл", "volume", 1, ["мл", "миллилитр", "ml", "куб", "кубик", "кубический сантиметр", "см3"]),
    ("л", "volume", 1000, ["л", "литр", "l", "кубический дециметр", "дм3"]),
    ("м³", "volume", 1_000_000, ["м3", "кубический метр", "куб.м"]),
    ("мм²", "area", 1, ["мм2", "квадратный миллиметр"]),
    ("см²", "area", 100, ["см2", "квадратный сантиметр"]),
    ("м²", "area", 1_000_000, ["м2", "квадратный метр", "кв.м"]),
    ("км", "length", 1_000_000, ["км", "километр"]),
    ("г/м²", "paper_density", 1, ["г/м2", "г/м²", "г/кв.м", "гр/м2", "грамм/м2", "g/m2", "gsm"]),
    ("дюйм", "inch", 1, ["дюйм", '"', "″", "in", "inch"]),
    ("КБ", "data", 1 / 1024 ** 2, ["кб", "kb", "килобайт"]),
    ("МБ", "data", 1 / 1024, ["мб", "mb", "мегабайт"]),
    ("ГБ", "data", 1, ["гб", "gb", "гигабайт", "гиг"]),
    ("ТБ", "data", 1024, ["тб", "tb", "терабайт"]),
    ("Вт", "power", 1, ["вт", "w", "ватт"]),
    ("кВт", "power", 1000, ["квт", "kw", "киловатт"]),
    ("МВт", "power", 1_000_000, ["мвт", "мегаватт"]),
    ("л.с.", "hp", 1, ["лс", "лошадиная сила"]),
    ("В", "voltage", 1, ["вольт", "v"]),
    ("кВ", "voltage", 1000, ["кв", "киловольт", "kv"]),
    ("А", "current", 1, ["ампер"]),
    ("А·ч", "charge", 1, ["ач", "ампер-час", "a·ч", "ah", "мач"]),
    ("дБ", "db", 1, ["дб", "децибел", "db"]),
    ("Мбит/с", "bitrate", 1, ["мбит/с", "mbps", "мегабит в секунду"]),
    ("Гбит/с", "bitrate", 1000, ["гбит/с", "gbps", "гигабит в секунду"]),
    ("кбит/с", "bitrate", 0.001, ["кбит/с", "kbps", "килобит в секунду"]),
    ("Гц", "freq", 1, ["гц", "hz", "герц"]),
    ("кГц", "freq", 1e3, ["кгц", "khz", "килогерц"]),
    ("МГц", "freq", 1e6, ["мгц", "mhz", "мегагерц"]),
    ("ГГц", "freq", 1e9, ["ггц", "ghz", "гигагерц"]),
    ("с", "time", 1, ["сек", "секунда"]),
    ("мс", "time", 0.001, ["миллисекунда"]),
    ("мин", "time", 60, ["минута"]),
    ("ч", "time", 3600, ["час"]),
    ("стр/мин", "print_speed", 1, ["страниц/мин", "стр/м", "ppm"]),
    ("%", "percent", 1, ["%", "процент"]),
    ("°C", "temp", 1, ["°c", "°с", "градус", "градус цельсия"]),
    # Счётные: у каждой своя «величина», чтобы «2 места» не ушло в листы.
    ("шт", "count", 1, ["шт", "штука", "pcs", "ед"]),
    ("лист", "count:лист", 1, ["лист", "листок"]),
    ("пара", "count:пара", 1, ["пара", "пар"]),
    ("место", "count:место", 1, ["место", "мест"]),
    ("слой", "count:слой", 1, ["слой", "слойный"]),
    ("секция", "count:секция", 1, ["секция"]),
    ("полка", "count:полка", 1, ["полка"]),
    ("ящик", "count:ящик", 1, ["ящик"]),
    ("рулон", "count:рулон", 1, ["рулон"]),
]


_PREPOSITIONS = {"в", "с", "к", "о", "у", "и", "а"}


def unit_key(written: str) -> str:
    """«Листов.» → «лист», «г/м²» → «г/м2», «″» → «"»."""
    u = written.strip().lower().replace("²", "2").replace("³", "3").replace("″", '"').replace(" ", "")
    u = u.rstrip(".").replace("ё", "е")
    u = u.replace("-", "")
    if "/" in u or not u.isalpha():
        return u.replace(".", "") if "/" in u else u
    return _parse(u)[0]


@lru_cache(maxsize=1)
def _registry() -> tuple[dict[str, Unit], dict[str, Unit]]:
    by_key: dict[str, Unit] = {}
    by_name: dict[str, Unit] = {}
    for name, dim, factor, spellings in _UNITS:
        unit = Unit(name, dim, factor)
        by_name[name] = unit
        for s in [name, *spellings]:
            key = unit_key(s)
            if key not in _PREPOSITIONS:  # «3 в 1», «2 с иглой» — не вольты и не секунды
                by_key.setdefault(key, unit)
    return by_key, by_name


def lookup(written: str) -> Unit | None:
    """Единица по написанию в тексте («граммов» → г)."""
    return _registry()[0].get(unit_key(written))


def canonical(name: str | None) -> Unit | None:
    """Единица характеристики по её каноническому имени («г/м²»)."""
    if not name:
        return None
    by_key, by_name = _registry()
    return by_name.get(name) or by_key.get(unit_key(name))


def convert(value: float, src: Unit, dst: Unit) -> float | None:
    """Перевод между единицами одной величины; «шт» и любая счётная («лист», «пара») взаимозаменяемы."""
    if src.dim == dst.dim:
        return round(value * src.factor / dst.factor, 6)
    if src.dim.startswith("count") and dst.dim.startswith("count") and "шт" in (src.name, dst.name):
        return value
    return None


def same_dim(unit: Unit) -> list[Unit]:
    """Другие единицы той же величины: «м» → мкм, мм, см, км."""
    return [u for u in _registry()[1].values() if u.dim == unit.dim and u.name != unit.name]


def describe(value: float, written: str | None, target: str | None) -> dict:
    """Что написано в тексте и как оно пересчитано в единицу характеристики: «3 тонны» → {3, т} → 3000 кг."""
    src, dst = lookup(written) if written else None, canonical(target)
    out = {"source": {"value": value, "unit": written, "unit_name": src.name if src else None},
           "conversion": None}
    if src and dst:
        factor = convert(1.0, src, dst)
        if factor is not None:
            out["conversion"] = {"factor": factor, "from": src.name, "to": dst.name,
                                 "result": round(value * factor, 6)}
    return out
